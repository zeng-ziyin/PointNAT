"""
Author: PointNeXt

"""
from .base_seg import BaseSeg, SegHead, BasePartSeg, MultiSegHead
# from .vit_seg import PointVitSeg